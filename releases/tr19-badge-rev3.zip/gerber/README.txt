Stackup is as follows:

Front (tr19-badge-F.*)
Inner 1 (tr19-badge-In1.*)
Inner 2 (tr19-badge-In2.*)
Back (tr19-badge-B.*)

1) Please panelise as per "panelisation-6-up.pdf"
2) Soldermask both sides _matte_ black if possible (please confirm)
3) Legend both sides _yellow_ if possible (please confirm)
4) Please make sure to create slots on J2 - see "j2-slots.pdf"

Any questions, please call Jeff Gough on +447903005844


